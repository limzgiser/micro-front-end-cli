#! /usr/bin/env node

require('./dist/index');
