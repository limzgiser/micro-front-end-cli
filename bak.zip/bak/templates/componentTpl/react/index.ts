import { createApp } from 'vue';
import Main from './main';

createApp(Main).mount('#{{name}}');

